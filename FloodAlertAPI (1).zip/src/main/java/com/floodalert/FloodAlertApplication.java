package com.floodalert;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FloodAlertApplication {
    public static void main(String[] args) {
        SpringApplication.run(FloodAlertApplication.class, args);
    }
}