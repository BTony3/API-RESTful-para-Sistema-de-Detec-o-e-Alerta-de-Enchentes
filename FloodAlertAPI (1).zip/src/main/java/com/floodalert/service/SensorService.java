package com.floodalert.service;

import com.floodalert.model.SensorData;
import com.floodalert.repository.SensorDataRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class SensorService {

    private final SensorDataRepository repository;

    public SensorService(SensorDataRepository repository) {
        this.repository = repository;
    }

    public SensorData save(double waterLevel, String weather) {
        SensorData data = new SensorData();
        data.setWaterLevel(waterLevel);
        data.setWeather(weather);
        data.setTimestamp(LocalDateTime.now());
        return repository.save(data);
    }

    public List<SensorData> getAll() {
        return repository.findAll();
    }
}