package com.floodalert.repository;

import com.floodalert.model.ControlAction;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ControlActionRepository extends JpaRepository<ControlAction, Long> {}