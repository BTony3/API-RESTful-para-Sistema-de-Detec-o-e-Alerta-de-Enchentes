package com.floodalert.controller;

import com.floodalert.model.SensorData;
import com.floodalert.service.SensorService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/sensors")
public class SensorController {

    private final SensorService service;

    public SensorController(SensorService service) {
        this.service = service;
    }

    @PostMapping
    public SensorData create(@RequestParam double waterLevel, @RequestParam String weather) {
        return service.save(waterLevel, weather);
    }

    @GetMapping
    public List<SensorData> all() {
        return service.getAll();
    }
}