package com.floodalert.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class ControlAction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String actionType;
    private LocalDateTime timestamp;
}